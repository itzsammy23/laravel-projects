$(document).ready(function () {

    var location = "/storage/cover_art/music-154176_640.png";
    $(".full__view__header").css("background-image", `linear-gradient(rgba(0, 0, 0, 0.50),  rgba(0, 0, 0, 0.75)), url(${location})`)

})
