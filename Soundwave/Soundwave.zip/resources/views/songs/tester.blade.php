@extends('layouts.app')

@section('content')
        <section class="playlist__full__view">
            <header class="full__view__header">

            </header>
        </section>
@endsection
