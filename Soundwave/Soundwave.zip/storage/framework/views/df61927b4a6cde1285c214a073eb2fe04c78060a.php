<?php $__env->startSection('content'); ?>
        <section class="playlist__full__view">
            <header class="full__view__header">

            </header>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Samuel O Kuteyi\Soundwave\resources\views/songs/tester.blade.php ENDPATH**/ ?>